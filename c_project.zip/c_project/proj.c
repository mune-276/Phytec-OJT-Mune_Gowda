#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TASKS 100

// Task status enumeration
enum TaskStatus {
    OPEN,
    IN_PROGRESS,
    DONE
};

// Task priority enumeration
enum TaskPriority {
    HIGH,
    MEDIUM,
    LOW
};

struct Task {
    int id;
    char description[100];
    char assignee[50];
    char assignedTo[50]; // New field: Assigned To
    char pendingTask[100];
    char scheduleMeeting[100];
    enum TaskStatus status; // New field: Task Status
    enum TaskPriority priority; // New field: Task Priority
};

struct Task tasks[MAX_TASKS];
int taskCount = 0;

// Function to find a task by ID
int findTaskById(int taskId) {
    for (int i = 0; i < taskCount; i++) {
        if (tasks[i].id == taskId) {
            return i;
        }
    }
    return -1; // Task not found
}

// Function to add a new task
void addTask() {
    if (taskCount < MAX_TASKS) {
        struct Task *task = &tasks[taskCount];

        printf("Enter task description: ");
        getchar(); // Consume the newline character left by previous input
        fgets(task->description, sizeof(task->description), stdin);
        task->description[strlen(task->description) - 1] = '\0'; // Remove newline

        printf("Enter assignee: ");
        fgets(task->assignee, sizeof(task->assignee), stdin);
        task->assignee[strlen(task->assignee) - 1] = '\0'; // Remove newline

        printf("Enter assigned to: ");
        fgets(task->assignedTo, sizeof(task->assignedTo), stdin); // New field: Assigned To
        task->assignedTo[strlen(task->assignedTo) - 1] = '\0'; // Remove newline

        printf("Enter pending task: ");
        fgets(task->pendingTask, sizeof(task->pendingTask), stdin);
        task->pendingTask[strlen(task->pendingTask) - 1] = '\0'; // Remove newline

        printf("Enter schedule for meeting: ");
        fgets(task->scheduleMeeting, sizeof(task->scheduleMeeting), stdin);
        task->scheduleMeeting[strlen(task->scheduleMeeting) - 1] = '\0'; // Remove newline

        printf("Enter status (0 - Open, 1 - In Progress, 2 - Done): ");
        int status;
        scanf("%d", &status);
        task->status = (enum TaskStatus)status;

        printf("Enter priority (0 - High, 1 - Medium, 2 - Low): ");
        int priority;
        scanf("%d", &priority);
        task->priority = (enum TaskPriority)priority;

        task->id = taskCount + 1; // Assign a unique ID
        taskCount++;

        printf("Task added!\n");
    } else {
        printf("Task list is full. Cannot add more tasks.\n");
    }
}

// Function to edit an existing task
void editTask() {
    int taskId;
    printf("Enter the task ID to edit: ");
    scanf("%d", &taskId);

    int taskIndex = findTaskById(taskId);
    if (taskIndex != -1) {
        struct Task *task = &tasks[taskIndex];

        printf("Edit Task %d:\n", taskId);
        printf("Enter updated task description: ");
        getchar(); // Consume the newline character left by previous input
        fgets(task->description, sizeof(task->description), stdin);
        task->description[strlen(task->description) - 1] = '\0'; // Remove newline

        printf("Enter updated assignee: ");
        fgets(task->assignee, sizeof(task->assignee), stdin);
        task->assignee[strlen(task->assignee) - 1] = '\0'; // Remove newline

        printf("Enter updated assigned to: ");
        fgets(task->assignedTo, sizeof(task->assignedTo), stdin); // New field: Assigned To
        task->assignedTo[strlen(task->assignedTo) - 1] = '\0'; // Remove newline

        printf("Enter updated pending task: ");
        fgets(task->pendingTask, sizeof(task->pendingTask), stdin);
        task->pendingTask[strlen(task->pendingTask) - 1] = '\0'; // Remove newline

        printf("Enter updated schedule for meeting: ");
        fgets(task->scheduleMeeting, sizeof(task->scheduleMeeting), stdin);
        task->scheduleMeeting[strlen(task->scheduleMeeting) - 1] = '\0'; // Remove newline

        printf("Enter updated status (0 - Open, 1 - In Progress, 2 - Done): ");
        int newStatus;
        scanf("%d", &newStatus);
        task->status = (enum TaskStatus)newStatus;

        printf("Enter updated priority (0 - High, 1 - Medium, 2 - Low): ");
        int newPriority;
        scanf("%d", &newPriority);
        task->priority = (enum TaskPriority)newPriority;

        printf("Task %d updated!\n", taskId);
    } else {
        printf("Task with ID %d not found.\n", taskId);
    }
}

// Function to list all tasks
void listTasks() {
    if (taskCount == 0) {
        printf("No tasks found.\n");
    } else {
        printf("\n%-4s | %-25s | %-12s | %-25s | %-25s | %-15s | %-15s\n", "ID", "Description", "Assignee", "Assigned To", "Pending Task", "Meeting", "Status", "Priority");
        printf("=============================================================================================================\n");
        for (int i = 0; i < taskCount; i++) {
            struct Task *task = &tasks[i];
            printf("%-4d | %-25s | %-12s | %-25s | %-25s | %-15s | %-15s\n", task->id, task->description, task->assignee, task->assignedTo, task->pendingTask, task->scheduleMeeting, task->status == OPEN ? "Open" : task->status == IN_PROGRESS ? "In Progress" : "Done", task->priority == HIGH ? "High" : task->priority == MEDIUM ? "Medium" : "Low");
        }
    }
}

// Function to view task details
void taskDetails() {
    int taskId;
    printf("Enter the task ID to view details: ");
    scanf("%d", &taskId);

    int taskIndex = findTaskById(taskId);
    if (taskIndex != -1) {
        struct Task *task = &tasks[taskIndex];
        printf("Task ID: %d\n", task->id);
        printf("Description: %s\n", task->description);
        printf("Assignee: %s\n", task->assignee);
        printf("Assigned To: %s\n", task->assignedTo);
        printf("Pending Task: %s\n", task->pendingTask);
        printf("Meeting: %s\n", task->scheduleMeeting);
        printf("Status: %s\n", task->status == OPEN ? "Open" : task->status == IN_PROGRESS ? "In Progress" : "Done");
        printf("Priority: %s\n", task->priority == HIGH ? "High" : task->priority == MEDIUM ? "Medium" : "Low");
    } else {
        printf("Task with ID %d not found.\n", taskId);
    }
}

// Function to delete a task
void deleteTask() {
    int taskId;
    printf("Enter the task ID to delete: ");
    scanf("%d", &taskId);

    int taskIndex = findTaskById(taskId);
    if (taskIndex != -1) {
        for (int i = taskIndex; i < taskCount - 1; i++) {
            tasks[i] = tasks[i + 1];
        }
        taskCount--;
        printf("Task %d deleted!\n", taskId);
    } else {
        printf("Task with ID %d not found.\n", taskId);
    }
}

int main() {
    int choice;

    do {
        printf("\nJira-like Task Management\n");
        printf("1. Add Task\n");
        printf("2. List Tasks\n");
        printf("3. Edit Task\n");
        printf("4. View Task Details\n");
        printf("5. Delete Task\n");
        printf("6. Quit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addTask();
                break;
            case 2:
                listTasks();
                break;
            case 3:
                editTask();
                break;
            case 4:
                taskDetails();
                break;
            case 5:
                deleteTask();
                break;
            case 6:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);

    return 0;
}

